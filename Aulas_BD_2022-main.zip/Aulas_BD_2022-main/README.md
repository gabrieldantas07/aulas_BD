# Aulas_BD_2022

# REPOSITÓRIO PARA OS ARQUIVOS DAS AULAS DE BANCO DE DADOS

Neste repositório serão disponibilizados os exercícios e as aulas práticas de Banco de Dados


LINK PARA A FERRAMENTA BR-MODELO (MODELAGEM DE BANCO DE DADOS) ==> http://www.sis4.com/brModelo/brModelo.2.0.zip
